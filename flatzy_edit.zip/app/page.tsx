"use client"

import { useState } from "react"
import Navbar from "../components/Navbar"
import Footer from "../components/Footer"
import ChatBot from "../components/ChatBot"
import Hero from "../components/Hero"
import FilterSection from "../components/FilterSection"
import PropertiesSection from "../components/PropertiesSection"
import ServicesSection from "../components/ServicesSection"
import TestimonialsSection from "../components/TestimonialsSection"

export default function Home() {
  const [activeFilter, setActiveFilter] = useState("All")
  const [searchData, setSearchData] = useState<
    { location: string; priceRange: string; propertyType: string } | undefined
  >()

  const handleFilterChange = (filter: string) => {
    setActiveFilter(filter)
  }

  const handleSearch = (data: { location: string; priceRange: string; propertyType: string }) => {
    setSearchData(data)
    // Scroll to properties section
    const propertiesSection = document.getElementById("properties")
    if (propertiesSection) {
      propertiesSection.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <main>
        <Hero onSearch={handleSearch} />
        <FilterSection onFilterChange={handleFilterChange} />
        <div id="properties">
          <PropertiesSection activeFilter={activeFilter} searchData={searchData} />
        </div>
        <ServicesSection />
        <TestimonialsSection />
      </main>
      <Footer />
      <ChatBot />
    </div>
  )
}
