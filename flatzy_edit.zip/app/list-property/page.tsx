import Navbar from "../../components/Navbar"
import Footer from "../../components/Footer"
import ChatBot from "../../components/ChatBot"

export default function ListProperty() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <div className="py-20 text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">List Your Property</h1>
        <p className="text-lg text-gray-600">Coming Soon - Property listing feature</p>
      </div>
      <Footer />
      <ChatBot />
    </div>
  )
}
