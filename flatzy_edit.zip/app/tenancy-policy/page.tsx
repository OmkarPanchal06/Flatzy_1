import Navbar from "../../components/Navbar"
import Footer from "../../components/Footer"
import ChatBot from "../../components/ChatBot"

export default function TenancyPolicy() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Tenancy Policy</h1>
          <p className="text-lg text-gray-600">Guidelines and policies for tenants using flatzy platform</p>
        </div>
        <div className="prose prose-lg max-w-none">
          <p className="text-gray-600 leading-relaxed">
            This Tenancy Policy outlines the guidelines, responsibilities, and procedures for tenants using the flatzy
            platform. By using our services, you agree to comply with these policies to ensure a positive rental
            experience for all parties involved.
          </p>
          {/* Add more tenancy policy content here */}
        </div>
      </div>
      <Footer />
      <ChatBot />
    </div>
  )
}
