import Navbar from "../../components/Navbar"
import Footer from "../../components/Footer"
import ChatBot from "../../components/ChatBot"

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Privacy Policy</h1>
          <p className="text-lg text-gray-600">Last updated: January 1, 2024</p>
        </div>
        <div className="prose prose-lg max-w-none">
          <p className="text-gray-600 leading-relaxed">
            At flatzy, we are committed to protecting your privacy and ensuring the security of your personal
            information. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when
            you use our website and services.
          </p>
          {/* Add more privacy policy content here */}
        </div>
      </div>
      <Footer />
      <ChatBot />
    </div>
  )
}
